<?php
/**
 * Child theme functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * Text Domain: oceanwp
 * @link http://codex.wordpress.org/Plugin_API
 *
 */

/**
 * Load the parent style.css file
 *
 * @link http://codex.wordpress.org/Child_Themes
 */
function oceanwp_child_enqueue_parent_style() {
	// Dynamically get version number of the parent stylesheet (lets browsers re-cache your stylesheet when you update your theme)
	$theme   = wp_get_theme( 'OceanWP' );
	$version = $theme->get( 'Version' );
	// Load the stylesheet
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'oceanwp-style' ), $version );
	
}
add_action( 'wp_enqueue_scripts', 'oceanwp_child_enqueue_parent_style' );

/* Custom URL Rewrite for Stats (team/bulldogs/stats) */
function inhl_stats_rewrite_rule() {
    add_rewrite_rule( 'team/([^/]+)/stats', 'index.php?sp_team=$matches[1]&stats=yes', 'top' );
}
add_action( 'init', 'inhl_stats_rewrite_rule' );

/* Register STATS Query Vars */
function inhl_register_query_var( $vars ) {
    $vars[] = 'stats';
 
    return $vars;
}
add_filter( 'query_vars', 'inhl_register_query_var' );

/* Set Template for Stats */
function inhl_url_rewrite_stats_template() {
    if ( get_query_var( 'stats' ) && is_singular( 'sp_team' ) ) {
            return get_stylesheet_directory() . '/team-stats.php';
    }
}