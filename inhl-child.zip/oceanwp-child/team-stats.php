<?php

get_header();

if( $_POST['season_name'] ){
    $season = $_POST['season_name'];
} else {
    $season = 35;
}

$team = get_queried_object_id();

$player_list = inhl_get_player_stats($team, $season);

function inhl_get_games($team, $season){
    $args = array(
        'post_type'=>'sp_event',
        'posts_per_page'=>-1,
        'orderby'=>'ID',
        'order'=>'ASC',
        'tax_query' => array(
            array(
                'taxonomy'=>'sp_season',
                'terms'=>$season,
            ),
        ),
        'meta_query' => array(
            array(
                'key'=>'sp_team',
                'value'=>$team,
                'compare'=>'=',
            ),
        ),
    );

    $games = new WP_Query($args);
    
    return $games;
}

//Return players stats per team/season
function inhl_get_player_stats($team, $season){

    $games = inhl_get_games($team, $season);

    if( $games->have_posts() ){

        $player_list = array();

        while ( $games->have_posts() ){

            $games->the_post();    
            $players = get_post_meta(get_the_ID(), 'sp_players', true );

            unset($players[$team][0]);

            foreach( $players[$team] as $k => $v ){
                $player_list[] = array(
                            'player_id'=>$k,
                            'number'=>$v['number'],
                            'position'=>$v['position'][0],
                            'g'=>$v['g'],
                            'a'=>$v['a'],
                            'pim'=>$v['pim'],
                            'sa'=>$v['sa'],
                            'ga'=>$v['ga'],
                            'sv'=>$v['sv'],
                        );
            }

        }
        
        foreach ($player_list as $row) {
            if (!isset($result[$row['player_id']])) {
                $result[$row['player_id']] = $row;
            } else {
                $result[$row['player_id']]['g'] += $row['g'];
                $result[$row['player_id']]['a'] += $row['a'];
                $result[$row['player_id']]['pim'] += $row['pim'];
                $result[$row['player_id']]['sa'] += $row['sa'];
                $result[$row['player_id']]['ga'] += $row['ga'];
                $result[$row['player_id']]['sv'] += $row['sv'];
            }
        }
        
        return $result;

    } else {
        return false;
    }
}

//Return Amount of games played
function inhl_count_played_games($team, $season, $player_id){
    $games = inhl_get_games($team, $season);
    $all_games = wp_list_pluck($games->posts, 'ID');
    
    $players_list = array();
    
    foreach( $all_games as $game ){
        $players = get_post_meta( $game, 'sp_players', true );
        unset($players[$team][0]);
        
        foreach( $players[$team] as $k=>$v ){
            $players_list[] = array( 'player_id'=>$k );
        }
    }
    $pid = array_column($players_list, 'player_id');
    $gp = array_count_values($pid);
    //return $count[$player_id];
    //return $gp[$player_id];
    return $gp[$player_id];
}


//Return amount of games won
function inhl_games_won($team, $season){   
    
    $games = inhl_get_games($team, $season );
    
    $outcome = array();
    $results = array();
    
    $games = wp_list_pluck($games->posts, 'ID');
    
    foreach( $games as $game ){
        $results[] = get_post_meta( $game, 'sp_results', true );
    }
    foreach( $results as $result ){
        $outcome[] = $result[$team]['outcome'][0];
    }
    
    $wins = array_count_values($outcome);
    return $wins['win']+$wins['overtimewin'];
}

//Display player stats table
function inhl_display_player_stats($player_list, $team, $season){
    $ouput = '<div class="sp-template sp-template-player-statistics">';
    $output .= '<div class="sp-table-wrapper">';
    $output .= '<h3 style="padding: 20px 0; margin: 0;">SKATERS</h3>';
    $output .= '<div class="dataTables_wrapper"><table class="sp-player-statistics sp-data-table skaters sp-scrollable-table">';
    $output .= '<thead>';
    $output .= '<tr>';
    $output .= '<th class="data-name">Player</th>';
    $output .= '<th class="data-gp">GP</th>';
    $output .= '<th class="data-g">G</th>';
    $output .= '<th class="data-a">A</th>';
    $output .= '<th class="data-p">P</th>';
    $output .= '<th class="data-pim">PIM</th>';
    $output .= '</tr>';
    $output .= '</thead>';
    $output .= '<tbody>';
    
    $i = 0;
    
    foreach( $player_list as $key=>$player ){
        
        if( $player['position'] == 28 ){
            continue;
        } else {
            $output .= '<tr class="' . ( $i % 2 == 0 ? 'odd' : 'even' ) . '">';
            $output .= '<td class="data-name" data-label="Player"><a href="'.get_the_permalink($key).'">'.get_the_title($key).'</a></td>';
            $output .= '<td class="data-gp" data-label="GP">'.inhl_count_played_games($team, $season, $key).'</td>';
            $output .= '<td class="data-g" data-label="G">'.intval( $player['g'] ).'</td>';
            $output .= '<td class="data-a" data-label="A">'.intval ( $player['a'] ).'</td>';
            $output .= '<td class="data-p" data-label="P">'.intval ( $player['g'] + $player['a']  ).'</td>';
            $output .= '<td class="data-pim" data-label="PIM">'.intval ( $player['pim'] ).'</td>';
            $output .= '</tr>';   
        }

        $i++;
    }
    
    $output .= '</tbody>';
    $output .= '</table></div>';
    $output .= '<h3 style="padding: 20px 0; margin: 0;">GOALIES</h3>';
    $output .= '<table class="sp-player-statistics sp-data-table goalie sp-scrollable-table">';
    $output .= '<thead>';
    $output .= '<tr>';
    $output .= '<th class="data-name">Player</th>';
    $output .= '<th class="data-gp">GP</th>';
    $output .= '<th class="data-gaa">GAA</th>';
    $output .= '<th class="data-ga">GA</th>';
    $output .= '<th class="data-wins">WINS</th>';
    $output .= '<th class="data-sv">SV%</th>';
    $output .= '</tr>';
    $output .= '</thead>';
    $output .= '<tbody>';
    
    $i = 0;
    
    foreach( $player_list as $key=>$player ){
        
        if( $player['position'] == 27 ){
            continue;
        } else {
            
            $gp = inhl_count_played_games($team, $season, $key);
            
            $output .= '<tr class="' . ( $i % 2 == 0 ? 'odd' : 'even' ) . '">';
            $output .= '<td class="data-name" data-label="Player"><a href="'.get_the_permalink($key).'">'.get_the_title($key).'</a></td>';
            $output .= '<td class="data-gp" data-label="GP">'.$gp.'</td>';
            $output .= '<td class="data-gaa" data-label="GAA">'.inhl_goals_against( $player['ga'], $gp ).'</td>';
            $output .= '<td class="data-ga" data-label="GA">'.$player['ga'].'</td>';
            $output .= '<td class="data-wins" data-label="WINS">'.intval ( inhl_games_won($team, $season) ).'</td>';
            $output .= '<td class="data-sv" data-label="SV%">'.inhl_saves_percentage( $player['sa'], $player['sv'] ).'</td>';
            $output .= '</tr>';  
        }

        $i++;
    }
    
    $output .= '</tbody>';
    $output .= '</table>';
    $output .= '</div>';
    $output .= '</div>';
    
    echo $output;
}

function inhl_goals_against($ga,$gp){
    $gaa = $ga/$gp;
    return number_format( $gaa, 2);
}

function inhl_saves_percentage($sa,$sv){
    $saves = $sv/$sa * 100;
    return number_format($saves, 2);
}

function inhl_show_seasons($team_id, $season=35){
    $seasons = get_the_terms( $team_id, 'sp_season' );
    $the_seasons = wp_list_pluck($seasons, 'name', 'term_id');
    
    echo '<select name="season_name" onchange="this.form.submit()">';
    echo '<option>Select Season</option>';
    foreach($the_seasons as $k=>$v){
        if( $season == $k ){
            echo '<option value="'.$k.'" selected="selected">'.$v.'</option>';
        } else {
            echo '<option value="'.$k.'">'.$v.'</option>';
        }
    }
    echo '</select>';
}

?>
<main id="main" class="site-main clr" role="main">
    <style>
        .ihl-players tr:nth-child(even) {
          background-color: #f2f2f2;
        }
    </style>
    <div id="content-wrap" class="container clr">

        <div id="primary" class="clr">

            <div id="content" class="site-content clr">
                <div class="ihl-filters" style="padding-bottom: 20px; border-bottom: 1px solid #ccc;">
                    <form method="post">
                        <div class="ihl-seasons" style="display: inline-block; vertical-align: middle;">
                            <?php inhl_show_seasons( $team, $season ); ?>
                        </div>
                    </form>
                </div>
                <div class="sportspress">
                    <?php inhl_display_player_stats($player_list, $team, $season); ?>
                </div>
            </div><!-- #content -->

        </div><!-- #primary -->

    </div><!-- #content-wrap -->

</main>
<script>
    jQuery(window).load(function(){
        jQuery('.sp-data-table.skaters').dataTable({
            paging: false,
            searching: false,
            info: false,
            order: [[4, 'desc']],
            
        });
        jQuery('.sp-data-table.goalie').dataTable({
            paging: false,
            searching: false,
            info: false,
            order: [[2, 'desc']],
            
        });
    });
</script>
<?php
    get_footer();
?>
