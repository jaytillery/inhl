<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that other
 * 'pages' on your WordPress site will use a different template.
 *
 * @package OceanWP WordPress them
 */

//Get Team ID
$team_id = get_the_ID();

//Show dropdown of current seasons played
function show_seasons($team_id){
    $seasons = get_the_terms( $team_id, 'sp_season' );
    $the_seasons = wp_list_pluck($seasons, 'name', 'slug');
    
    echo '<select name="season_name" id="inhl-event-list-filter">';
    echo '<option value="0">Select Season</option>';
    foreach($the_seasons as $k=>$v){
        echo '<option value="'.$k.'">'.$v.'</option>';
    }
    echo '</select>';
}

get_header(); 

    if( get_query_var('stats') ){
        require( get_template_directory() . '/team-stats.php' );
        exit;
    }
?>


	<?php do_action( 'ocean_before_content_wrap' ); ?>

	<div id="content-wrap" class="container clr">
        <div class="inhl-filters" style="margin-bottom: 25px; padding-bottom: 25px;">
            <div class="inhl-show-seasons" style="display: inline-block; vertical-align: middle;">
                <?php show_seasons($team_id); ?>
            </div> 
            <div class="inhl-player-team-stats" style="display: inline-block; vertical-align: middle;">
                <a href="<?php the_permalink(); ?>stats" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">PLAYER STATS</span>
		                </span>
				</a>
            </div>
        </div>

		<?php do_action( 'ocean_before_primary' ); ?>

		<div id="primary" class="content-area clr">

			<?php do_action( 'ocean_before_content' ); ?>

			<div id="content" class="site-content clr">

				<?php do_action( 'ocean_before_content_inner' ); ?>
                
				<?php
				// Elementor `single` location.
				if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {

					// Start loop.
					while ( have_posts() ) :
						the_post();

						get_template_part( 'partials/page/layout' );

					endwhile;

				}
				?>

				<?php do_action( 'ocean_after_content_inner' ); ?>

			</div><!-- #content -->

			<?php do_action( 'ocean_after_content' ); ?>

		</div><!-- #primary -->

		<?php do_action( 'ocean_after_primary' ); ?>

	</div><!-- #content-wrap -->

	<?php do_action( 'ocean_after_content_wrap' ); ?>

        <script type="text/javascript">
            jQuery(document).ready(function () {
                jQuery("#inhl-event-list-filter").change(function () {
                    var inputVal = jQuery(this).val();
                    var eleBox = jQuery("." + inputVal);
                    if( inputVal == 0 ){
                        jQuery(".inhl-season").show();
                    } else {
                        jQuery(".inhl-season").hide();
                        jQuery(eleBox).show();
                        console.log(inputVal);   
                    }
                });
            });
        </script>
<?php get_footer(); ?>
